package com.beans;

public class Faculty 
{
	private int id;
	private String name;
	private String uId;
	private String password;
	public Faculty() {
		// TODO Auto-generated constructor stub
	}
	public Faculty(int id, String name, String uId, String password) {
		super();
		this.id = id;
		this.name = name;
		this.uId = uId;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
