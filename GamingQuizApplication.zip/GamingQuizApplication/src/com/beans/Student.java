package com.beans;

public class Student 
{
	private String studentId;
	private String name;
	private String courseCode,regionCode;
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	private int centreCode;
	private String batchCode;
	private String userId;
	private String password;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public int getCentreCode() {
		return centreCode;
	}
	public void setCentreCode(int centreCode) {
		this.centreCode = centreCode;
	}
	public String getBatchCode() {
		return batchCode;
	}
	public void setBatchCode(String batchCode) {
		this.batchCode = batchCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", courseCode=" + courseCode + ", centreCode="
				+ centreCode + ", batchCode=" + batchCode + ", userId=" + userId + ", password=" + password + "]";
	}
	
}
