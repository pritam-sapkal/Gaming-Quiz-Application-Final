package com.beans;

public class AnswerKey 
{
	private int qId;
	private String question;
	private String correctOption;
	private int maxMrks;
	public AnswerKey(int qId, String question, String correctOption, int maxMrks) {
		super();
		this.qId = qId;
		this.question = question;
		this.correctOption = correctOption;
		this.maxMrks = maxMrks;
	}
	public AnswerKey() {
		// TODO Auto-generated constructor stub
	}
	public int getqId() {
		return qId;
	}
	public void setqId(int qId) {
		this.qId = qId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getCorrectOption() {
		return correctOption;
	}
	public void setCorrectOption(String correctOption) {
		this.correctOption = correctOption;
	}
	public int getMaxMrks() {
		return maxMrks;
	}
	public void setMaxMrks(int maxMrks) {
		this.maxMrks = maxMrks;
	}
	
}
