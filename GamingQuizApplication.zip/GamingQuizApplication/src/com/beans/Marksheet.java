package com.beans;

public class Marksheet
{
	public String studentId;
	public int session;
	public String batchCode,result,sessionName;
	public int marksObtained,batchRank,regionRank,nationalRank;
	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public Marksheet() {
		// TODO Auto-generated constructor stub
	}
	
	public Marksheet(String studentId, int session, String batchCode, String result, int marksObtained, int batchRank,
			int regionRank, int nationalRank) {
		super();
		this.studentId = studentId;
		this.session = session;
		this.batchCode = batchCode;
		this.result = result;
		this.marksObtained = marksObtained;
		this.batchRank = batchRank;
		this.regionRank = regionRank;
		this.nationalRank = nationalRank;
	}

	public String getStudentId() {
		return studentId;
	}
	@Override
	public String toString() {
		return "Marksheet [studentId=" + studentId + ", session=" + session + ", batchCode=" + batchCode + ", result="
				+ result + ", sessionName=" + sessionName + ", marksObtained=" + marksObtained + ", batchRank="
				+ batchRank + ", regionRank=" + regionRank + ", nationalRank=" + nationalRank + "]";
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public int getSession() {
		return session;
	}
	public void setSession(int session) {
		this.session = session;
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public int getBatchRank() {
		return batchRank;
	}

	public void setBatchRank(int batchRank) {
		this.batchRank = batchRank;
	}

	public int getRegionRank() {
		return regionRank;
	}

	public void setRegionRank(int regionRank) {
		this.regionRank = regionRank;
	}

	public int getNationalRank() {
		return nationalRank;
	}

	public void setNationalRank(int nationalRank) {
		this.nationalRank = nationalRank;
	}

	public String getBatchCode() {
		return batchCode;
	}
	public void setBatchCode(String batchCode) {
		this.batchCode = batchCode;
	}
	public int getMarksObtained() {
		return marksObtained;
	}
	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}
	
}
