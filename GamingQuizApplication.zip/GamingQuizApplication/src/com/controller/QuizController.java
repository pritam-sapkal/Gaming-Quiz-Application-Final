package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.Question;
import com.beans.Student;

/**
 * Servlet implementation class QuizController
 */

@WebServlet("/SecondServlet")
public class QuizController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public QuizController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: Quiz controller").append(request.getContextPath());
		System.out.println(request.getParameter("flag"));
		int count = Integer.parseInt(request.getParameter("count"));
		HttpSession session = request.getSession();
		System.out.println(session);
		Student s = (Student) session.getAttribute("currentStudent");
		System.out.println(s);
		String batchCode = s.getBatchCode();
		int examSession = (int) session.getAttribute("examSession");
		System.out.println(examSession);
		String courseCode = s.getCourseCode();
		System.out.println("course code " + courseCode);
		Connection con = (Connection) session.getAttribute("databaseconnection");
		System.out.println("conn" + con);
		int score;
		// if(count==1)
		score = (int) session.getAttribute("score");
		// else
		// score=Integer.parseInt(request.getParameter("score"));
		System.out.println("Score after quest" + score);
		System.out.println("count in controller" + count);

		if (count <= 4) {
			if (count > 0) {

				Question q = (Question) session.getAttribute("currentQuestion");
				String ansGiven = request.getParameter("ans");
				if (ansGiven != null) {
					if (ansGiven.equals(q.getCorrectOption())) {
						int time = Integer.parseInt(request.getParameter("time"));
						System.out.println("Answer given in " + time + " seconds");
						int marks = 0;
						if(time<=10)
							marks=5;
						else if(time<=15)
							marks=4;
						else if(time<=20)
							marks=3;
						else if(time<=25)
							marks=2;
						else if(time<=30)
							marks=1;
						else
							marks=0;
						session.setAttribute("score", (score + marks));
						request.setAttribute("score", (score + marks));
						System.out.println("Answer is correct");
					} else {
						System.out.println("wrong answer given");
					}
				}
			}
			if (count < 4) {
				String sql = "select *from questionbank where CourseCode=? and SessionID=? order by rand() limit 1";
				PreparedStatement ps = null;
				ResultSet rs = null;
				try {
					ps = con.prepareStatement(sql);
					ps.setString(1, courseCode);
					ps.setInt(2, examSession);

					rs = ps.executeQuery();
					// rs.next();
					// System.out.println("After result set qid"+rs.getInt(1));
					if (rs.next()) {
						Question currentQuestion = new Question();
						currentQuestion.setQid(rs.getInt(1));
						currentQuestion.setQuestion(rs.getString(2));
						currentQuestion.setOption1(rs.getString(3));
						currentQuestion.setOption2(rs.getString(4));
						currentQuestion.setOption3(rs.getString(5));
						currentQuestion.setOption4(rs.getString(6));
						currentQuestion.setCorrectOption(rs.getString(7));
						currentQuestion.setMark(rs.getInt(10));
						request.setAttribute("currentQuestion", currentQuestion);
						count++;
						request.setAttribute("count", count);
						// request.setAttribute("score", score);
						System.out.println(currentQuestion);
						RequestDispatcher rd = request.getRequestDispatcher("/StartQuiz.jsp");
						rd.forward(request, response);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				System.out.println("in outer else");

				String result = "fail";
				String sid = s.getStudentId();
				String sql = "insert into resulttransaction(SID,BatchCode,SessionID,ExamAttempted,TotalMarks,Result) values(?,?,?,?,?,?)";
				PreparedStatement p;
				try {
					p = con.prepareStatement(sql);
					p.setString(1, sid);
					p.setString(2, batchCode);
					p.setInt(3, examSession);
					p.setString(4, "Y");
					p.setInt(5, (int) session.getAttribute("score"));

					if (((int) session.getAttribute("score")) >=5)
						result = "pass";
					p.setString(6, result);
					// p.setDate(7, d);
					int status = p.executeUpdate();
					if (status > 0)
						System.out.println("Record added in result transaction");
					if(result.equals("pass"))
					{
						p=con.prepareStatement("select SessionName from session where SessionID=?");
						p.setInt(1, examSession);
						ResultSet r1=p.executeQuery();
						r1.next();
						String sessionName=r1.getString(1);
						p=con.prepareStatement("select CentreCode from student where StudentID=?");
						p.setString(1, sid);
						r1=p.executeQuery();
						r1.next();
						int centreCode=r1.getInt(1);
						p=con.prepareStatement("select RegionCode from centre where CentreCode=?");
						p.setInt(1, centreCode);
						r1=p.executeQuery();
						r1.next();
						String regionCode=r1.getString(1);
						
						p=con.prepareStatement("insert into studentpasshistory(SID,BatchCode,SessionName,Marks,CentreCode,RegionCode,CourseCode) values(?,?,?,?,?,?,?)");
						p.setString(1, sid);
						p.setString(2, batchCode);
						p.setString(3, sessionName);
						p.setInt(4, (int) session.getAttribute("score"));
						p.setInt(5, centreCode);
						p.setString(6, regionCode);
						p.setString(7, courseCode);
						int stat=p.executeUpdate();
						if(stat>0)
						{
							System.out.println("Record added in new table");
						}
					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				System.out.println("total marks " + (int) session.getAttribute("score"));
				RequestDispatcher rd = request.getRequestDispatcher("logout.jsp");
				PrintWriter o = response.getWriter();
				response.setContentType("text/html");
				o.print("<h3>Quiz completed");
				rd.include(request, response);
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
