package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.Student;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Connection con = null;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	static {
		System.out.println("static block");
		String url = "jdbc:mysql://localhost:3306/gamingquizapplication";
		String uname = "root";
		String pass = "root";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("class loaded");
			con = DriverManager.getConnection(url, uname, pass);
			System.out.println("conn created");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public LoginController() {
		super();
		// TODO Auto-generated constructor stub

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.setAttribute("databaseconnection", con);
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("Requested");
		String role = request.getParameter("role");
		String uname = request.getParameter("username");
		String password = request.getParameter("pass");
		session.setAttribute("username", uname);
		System.out.println(uname + " " + password);
		if (role.equals("Student")) {
			try {
				boolean flag = false;
				Statement st = con.createStatement();
				String query = "select UserID,Password from gamingquizapplication.student";
				ResultSet rs = st.executeQuery(query);
				while (rs.next()) {

					String un = rs.getString(1);
					String pa = rs.getString(2);
					if (un.equals(uname) && password.equals(pa))
					{
						flag = true;
						break;
					}
				}
				if (flag == true) {
					PreparedStatement s = con.prepareStatement("select * from student where UserID=?");
					s.setString(1, uname);
					ResultSet r = s.executeQuery();
					if (r.next()) {
						String studentId = r.getString(1);
						String studentName = r.getString(2);
						String courseCode = r.getString(3);
						int centreCode = r.getInt(4);
						String batchCode = r.getString(5);
						String userId = r.getString(6);

						Student currentStudent = new Student();
						currentStudent.setStudentId(studentId);
						currentStudent.setName(studentName);
						currentStudent.setCourseCode(courseCode);
						currentStudent.setCentreCode(centreCode);
						currentStudent.setBatchCode(batchCode);
						currentStudent.setUserId(userId);
						
						PreparedStatement pp=con.prepareStatement("select RegionCode from centre where CentreCode=?");
						pp.setInt(1, centreCode);
						ResultSet s1=pp.executeQuery();
						s1.next();
						String regionCode=s1.getString(1);
						currentStudent.setRegionCode(regionCode);
						

						session.setAttribute("currentStudent", currentStudent);

						System.out.println("Login success");
						RequestDispatcher rd = request.getRequestDispatcher("StudentHome.jsp");
						rd.forward(request, response);
					}
				} 
				else
				{
					System.out.println("Login failed");
					 response.setContentType("text/html");  
					PrintWriter o = response.getWriter();
					o.print("<h2><p style='color:red'>Wrong credentials...</p></h2>");
					
					RequestDispatcher rd = request.getRequestDispatcher("/Welcome.html");
					rd.include(request, response);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (role.equals("Faculty")) {
			try {
				boolean flag = false;
				Statement st = con.createStatement();
				String query = "select UserId,Password from gamingquizapplication.faculty";
				ResultSet rs = st.executeQuery(query);
				System.out.println(rs);
				while (rs.next()) {

					String un = rs.getString(1);
					String pa = rs.getString(2);
					if (un.equals(uname) && password.equals(pa))
					{
						flag = true;
						break;
					}
				}
				if (flag == true) {
					PreparedStatement s = con.prepareStatement("select FacultyName from faculty where UserID=?");
					s.setString(1, uname);
					ResultSet r = s.executeQuery();
					if (r.next()) {
						String facultyName = r.getString(1);

						session.setAttribute("FacultyName", facultyName);

						System.out.println("Login success");
						RequestDispatcher rd = request.getRequestDispatcher("FacultyHome.jsp");
						rd.include(request, response);
					}
				} else {
					
					
					System.out.println("Login failed");
					 response.setContentType("text/html");  
					PrintWriter o = response.getWriter();
					o.print("<h2><p style='color:red'>Wrong credentials...</p></h2>");
					
					RequestDispatcher rd = request.getRequestDispatcher("/Welcome.html");
					rd.include(request, response);
				
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
