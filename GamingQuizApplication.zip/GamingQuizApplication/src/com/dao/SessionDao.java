package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.beans.Session;

public class SessionDao 
{
	public static Connection getConnection(){  
	    Connection con=null;  
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gamingquizapplication","root","root");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}  
	public static int completeSession(Session s){  
	    int status=0;  
	    System.out.println("To mark completed "+s.getSessionId()+" "+s.getBatchCode());
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement(  
	"update sessiontransaction set Status='C' where SessionID=? and BatchCode=?");  
	        ps.setInt(1,s.getSessionId());  
	        ps.setString(2, s.getBatchCode());
	        status=ps.executeUpdate();  
	        System.out.println("Session marked with status: "+status);
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	} 
	public static List<Session> getAllSessions(String uname){  
	    List<Session> list=new ArrayList<Session>();  
	  
	    
	    
	    
	    try{  
	        Connection con=getConnection();
	        PreparedStatement p=con.prepareStatement("select BatchCode from batch where FacultyID=(Select FacultyID from faculty where UserID=?)");
	        p.setString(1, uname);
	        
	        ResultSet rs1=p.executeQuery();
	        rs1.next();
	        String bcode=rs1.getString(1);
	        System.out.println("batch code : "+bcode);
	        
	        PreparedStatement ps=con.prepareStatement("select t1.BatchCode,t1.sessionID,t2.SessionName,t2.CourseCode from sessiontransaction t1,sessionmaster t2 where t1.SessionID=t2.SessionId and t1.Status='I' and BatchCode=?");  
	        ps.setString(1,bcode);
//	        PreparedStatement ps=con.prepareStatement("select * from session where Status='I' and BatchCode IN(select BatchCode from) ");  
	        ResultSet rs=ps.executeQuery();  
	        System.out.println("Query ok");
	        while(rs.next()){  
	        	System.out.println("ok");
	        	Session s=new Session();  
	            s.setSessionId(rs.getInt("SessionID"));
	            s.setSessionName(rs.getString("SessionName"));
	            s.setCourseCode(rs.getString("CourseCode"));
	            s.setBatchCode(rs.getString("BatchCode"));  
	            list.add(s);  
	        }  
	    }catch(Exception e){e.printStackTrace();}  
	    return list;  
	}  
}
