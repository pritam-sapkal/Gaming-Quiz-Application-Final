package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.beans.Marksheet;
import com.beans.Session;

public class StudentRecordsDao {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gamingquizapplication", "root", "root");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static List<Marksheet> getStudentRecord(String sID) {
		List<Marksheet> list = new ArrayList<>();
		try {
			String regionCode=null;
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from studentpasshistory where SID=?");
			ps.setString(1, sID);
			// PreparedStatement ps=con.prepareStatement("select * from session where
			// Status='I' and BatchCode IN(select BatchCode from) ");
			ResultSet rs = ps.executeQuery();
			System.out.println("Query ok");
			while (rs.next()) {
				System.out.println("ok");
				Marksheet s = new Marksheet();
				regionCode=rs.getString(9);
				s.setStudentId(rs.getString(1));
				String batchCode = rs.getString(2);
				s.setBatchCode(batchCode);
				// int ses=rs.getInt(3);
				// s.setSession(ses);
				s.setMarksObtained(rs.getInt(4));
				s.setResult("Pass");

				/*
				 * ps = con.
				 * prepareStatement("select SessionName from session where SessionID=? and BatchCode=?"
				 * ); ps.setInt(1, ses); ps.setString(2, batchCode); ResultSet
				 * inRs=ps.executeQuery(); while(inRs.next()) {
				 */
				String sessionName=rs.getString(3);
				s.setSessionName(rs.getString(3));

				// setting batch rank
				String s1 = "select SID,@currRank:=@currRank+1 AS rank from studentpasshistory h,(select@currRank:=0)r where h.SessionName=? and BatchCode=? order by Marks;";
				ps = con.prepareStatement(s1);
				ps.setString(1, rs.getString(3));
				ps.setString(2, batchCode);
				ResultSet ss = ps.executeQuery();
				int batchRank = 0;
				while (ss.next()) {
					if (ss.getString(1).equals(sID)) {
						batchRank = ss.getInt(2);
						break;
					}
				}

				s.setBatchRank(batchRank);

				System.out.println("session name : "+sessionName);
				System.out.println("region code : "+regionCode);
				//setting region rank
				String s2 = "select SID,@currRank:=@currRank+1 AS rank from studentpasshistory h,(select@currRank:=0)r where h.SessionName=? and h.RegionCode=? order by h.Marks";
				ps = con.prepareStatement(s2);
				ps.setString(1, sessionName);
				ps.setString(2, regionCode);
				ResultSet sss = ps.executeQuery();
				int regionRank = 0;
				while (sss.next())
				{
					System.out.println("in loop");
					if (sss.getString(1).equals(sID)) {
						regionRank = sss.getInt(2);
						break;
					}
				}
				
				System.out.println("Region rank : "+regionRank);
				s.setRegionRank(regionRank);
				
				//Setting national rank
				s2 = "select SID,@currRank:=@currRank+1 AS rank from studentpasshistory h,(select@currRank:=0)r where h.SessionName=? order by h.Marks;";
				ps = con.prepareStatement(s2);
				ps.setString(1, sessionName);
	
				ResultSet snew = ps.executeQuery();
				int nationalRank = 0;
				while (snew.next())
				{
					System.out.println("in loop");
					if (snew.getString(1).equals(sID)) {
						nationalRank = snew.getInt(2);
						break;
					}
				}
				
				s.setNationalRank(nationalRank);
				System.out.println(nationalRank);
				list.add(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (Marksheet m : list)
			System.out.println(m);
		return list;

	}

	private static int getNationalRank() {

		String sqp = "select SID,@currRank:=@currRank+1 AS rank from studentpasshistory h,(select@currRank:=0) where h.SessionName=? and BatchCode=? order by Marks;";
		return 0;
	}

	private static int getRegionRank() {
		// TODO Auto-generated method stub
		return 0;
	}

	private static int getBatchRank() {
		// TODO Auto-generated method stub
		return 0;
	}
}
