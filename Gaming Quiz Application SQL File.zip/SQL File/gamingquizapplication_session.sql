CREATE DATABASE  IF NOT EXISTS `gamingquizapplication` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gamingquizapplication`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: gamingquizapplication
-- ------------------------------------------------------
-- Server version	5.6.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `SessionID` int(11) NOT NULL,
  `SessionName` varchar(45) DEFAULT NULL,
  `CourseCode` varchar(45) NOT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `BatchCode` varchar(45) NOT NULL,
  PRIMARY KEY (`SessionID`,`CourseCode`,`BatchCode`),
  KEY `CourseCode_idx` (`CourseCode`),
  KEY `BatchCode_idx` (`BatchCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (1,'Introduction to Java','PIJ','I','B200270'),(1,'Introduction to Java','PIJ','I','B200300'),(1,'Introduction to C++','PUC','I','B200254'),(1,'Introduction to C++','PUC','I','B200400'),(2,'OOPS','PIJ','I','B200270'),(2,'OOPS','PIJ','I','B200300'),(2,'OOPS','PUC','I','B200300'),(2,'OOPS','PUC','I','B200400'),(3,'Language Fundamentals','PIJ','I','B200270'),(3,'Language Fundamentals','PIJ','I','B200300'),(3,'Language Fundamentals','PUC','I','B200300'),(3,'Language Fundamentals','PUC','I','B200400'),(4,'String','PIJ','I','B200270'),(4,'String','PIJ','I','B200300'),(4,'String','PUC','I','B200300'),(4,'String','PUC','I','B200400'),(5,'Inheriatance','PIJ','I','B200270'),(5,'Inheriatance','PIJ','I','B200300'),(5,'Inheriatance','PUC','I','B200300'),(5,'Inheriatance','PUC','I','B200400'),(6,'Collection','PIJ','I','B200270'),(6,'Collection','PIJ','I','B200300'),(6,'Polymorphism','PUC','I','B200300'),(6,'Polymorphism','PUC','I','B200400'),(7,'Exception','PIJ','I','B200270'),(7,'Exception','PIJ','I','B200300'),(7,'Pinters','PUC','I','B200300'),(7,'Pinters','PUC','I','B200400'),(8,'Multi Threading','PIJ','I','B200270'),(8,'Multi Threading','PIJ','I','B200300'),(8,'Virual','PUC','I','B200300'),(8,'Virual','PUC','I','B200400'),(9,'File IO','PIJ','I','B200270'),(9,'File IO','PIJ','I','B200300'),(10,'JDBC','PIJ','I','B200270'),(10,'JDBC','PIJ','I','B200300');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-19 21:31:45
