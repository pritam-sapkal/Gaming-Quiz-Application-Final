CREATE DATABASE  IF NOT EXISTS `gamingquizapplication` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gamingquizapplication`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: gamingquizapplication
-- ------------------------------------------------------
-- Server version	5.6.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `questionbank`
--

DROP TABLE IF EXISTS `questionbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionbank` (
  `QID` int(11) NOT NULL,
  `Question` varchar(450) DEFAULT NULL,
  `Option1` varchar(200) DEFAULT NULL,
  `Option2` varchar(200) DEFAULT NULL,
  `Option3` varchar(200) DEFAULT NULL,
  `Option4` varchar(200) DEFAULT NULL,
  `CorrectOption` varchar(200) DEFAULT NULL,
  `SessionID` int(11) DEFAULT NULL,
  `CourseCode` varchar(45) DEFAULT NULL,
  `Marks` int(11) DEFAULT NULL,
  PRIMARY KEY (`QID`),
  KEY `SessionID1_idx` (`SessionID`),
  KEY `CourseCode2_idx` (`CourseCode`),
  CONSTRAINT `sessid` FOREIGN KEY (`SessionID`) REFERENCES `sessionmaster` (`SessionId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionbank`
--

LOCK TABLES `questionbank` WRITE;
/*!40000 ALTER TABLE `questionbank` DISABLE KEYS */;
INSERT INTO `questionbank` VALUES (1,'What is the type of variable ‘b’ and ‘d’ in the following Java snippet?\nint a[], b;\nint []c, d;','‘b’ and ‘d’ are int','‘b’ and ‘d’ are arrays of type int','‘b’ is int variable; ‘d’ is int array','‘d’ is int variable; ‘b’ is int array','‘b’ is int variable; ‘d’ is int array',1,'PIJ',5),(2,'Which of these is an incorrect array declaration?','int arr[] = new int[5] ;','int [] arr = new int[5] ;','int arr[];\narr = new int[5];\n','int arr[] = int [5] new;','int arr[] = int [5] new;',1,'PIJ',5),(3,'Which of the following are legal lines of Java code?\n   1. int w = (int)888.8;\n   2. byte x = (byte)100L;\n   3. long y = (byte)100;\n   4. byte z = (byte)100L;\n','1 and 2','2 and 3','3 and 4','All statements are correct\n','All statements are correct\n',1,'PIJ',5),(4,'Literal can be of which of these data types?','integer','float','boolean','all of the mentioned\n','all of the mentioned\n',1,'PIJ',5),(5,'Which of these can not be used for a variable name in Java?','identifier','keyword','identifier & keyword','none of the mentioned','keyword',1,'PIJ',5),(6,'Which one is a valid declaration of a boolean?\n','boolean b1 = 1;','boolean b2 = ‘false’;','boolean b3 = false;','boolean b4 = ‘true’','boolean b3 = false;\n',1,'PIJ',5),(7,'How to sort an array?\n','Array.sort()','Arrays.sort()','Collection.sort()','System.sort()','Arrays.sort()',1,'PIJ',5),(8,'Which of the following is not OOPS concept in Java?','Inheritance','Encapsulation','Polymorphism','Compilation\n','Compilation\n',2,'PIJ',5),(9,'Which of the following is a type of polymorphism in Java?','Compile time polymorphism','Execution time polymorphism\n','Multiple polymorphism','Multilevel polymorphism','Compile time polymorphism',2,'PIJ',5),(10,'When Overloading does not occur?','More than one method with same name but different method signature and different number or type of parameters','More than one method with same name, same signature but different number of signature','More than one method with same name, same signature, same number of parameters but different type','More than one method with same name, same number of parameters and type but different signature','More than one method with same name, same number of parameters and type but different signature',2,'PIJ',5),(11,'Which concept of Java is a way of converting real world objects in terms of class?','Polymorphism','Encapsulation\n','Abstraction','Inheritance','Abstraction',2,'PIJ',5),(12,'Which concept of Java is achieved by combining methods and attribute into a class?\n','Encapsulation\n','Inheritance','Polymorphism','none of the mentioned','Encapsulation',2,'PIJ',5),(13,'What is it called if an object has its own lifecycle and there is no owner?','Aggregation','Composition','Encapsulation','Association','Association',2,'PIJ',5),(14,'What is it called where child object gets killed if parent object is killed?','Aggregation','Composition','Encapsulation','Association','Aggregation',1,'PIJ',5),(15,'Which one of these lists contains only Java programming language keywords?','class, if, void, long, Int, continue','goto, instanceof, native, finally, default, throws','try, virtual, throw, final, volatile, transient','strictfp, constant, super, implements, do','goto, instanceof, native, finally, default, throws\n',3,'PIJ',5),(16,'Which will legally declare, construct, and initialize an array?\n','int [] myList = {\"1\", \"2\", \"3\"};\n','int [] myList = (5, 8, 2);\n','int myList [] [] = {4,9,7,0};','int myList [] = {4, 3, 7};','int myList [] = {4, 3, 7};',3,'PIJ',5),(17,'Which is a reserved word in the Java programming language?\n','method','native','subclasses\n','reference\n','native',3,'PIJ',5),(18,'Which is a valid keyword in java?','interface','string','Float','unsigned','interface',3,'PIJ',5),(19,'Which three are legal array declarations?\n\nint [] myScores [];\nchar [] myChars;\nint [6] myScores;\nDog myDogs [];\nDog myDogs [7];\n','1, 2, 4','2, 4, 5','2, 3, 4','All are correct.','1, 2, 4',3,'PIJ',5),(20,'public interface Foo \n{ \n    int k = 4; /* Line 3 */\n}\n\nWhich three piece of codes are equivalent to line 3?\nfinal int k = 4;\npublic int k = 4;\nstatic int k = 4;\nabstract int k = 4;\nvolatile int k = 4;\nprotected int k = 4;','1, 2 and 3','2, 3 and 4','3, 4 and 5','4, 5 and 6','1, 2 and 3',3,'PIJ',5),(21,'What is it called where child object gets killed if parent object is killed?','Aggregation','Composition','Encapsulation','Association','Aggregation',1,'PIJ',5),(22,'Which of these class is superclass of String and StringBuffer class?','java.util','java.lang','ArrayList','None of the mentioned','java.lang',4,'PIJ',5),(23,'Which of these operators can be used to concatenate two or more String objects?','+','+=','&','||','+',4,'PIJ',5),(24,'Which of this method of class String is used to obtain a length of String object?','get()','Sizeof()','lengthof()','length()','length()',4,'PIJ',5),(25,'Which of these method of class String is used to extract a single character from a String object?','CHARAT()','chatat()','charAt()','ChatAt()','charAt()',4,'PIJ',5),(26,'Which of these constructors is used to create an empty String object?','String()','String(void)','String(0)','None of the mentioned','String()',4,'PIJ',5),(27,'Which of these is an incorrect statement?','String objects are immutable, they cannot be changed','String object can point to some other reference of String variable','StringBuffer class is used to store string in a buffer for later use','None of the mentioned','StringBuffer class is used to store string in a buffer for later use',4,'PIJ',5),(28,'Which of this keyword must be used to inherit a class?','super','this','extends','except','extends',5,'PIJ',5),(29,'A class member declared protected becomes a member of subclass of which type?','public member','private member','protected member','None of the mentioned','private member',5,'PIJ',5),(30,'Which of these is correct way of inheriting class A by class B?','class B + class A {}','class B inherits class A {}','class B extends A {}','class B extends class A {}','class B extends A {}',5,'PIJ',5);
/*!40000 ALTER TABLE `questionbank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-19 21:31:43
